class Form {
    constructor(){}


   // hide(){
      // input.hide();
         // title.hide();
     // }

    display(){
    var title = createElement("h1");
    title.html("woojo");
    title.position(615,10)

    var input = createInput("Enter Name");
    input.position(590,150);

    var input2 = createInput("choose HERO or VAMP");
    input2.position(590,430); 

    /////////////// character outPut box ////////////////// 


    fill(230,179,207)
    rect(580,200,200,200);

    fill("black")
    textSize(20)
    text("<-- Choose character",585,300)  

    /////////////// images and score //////////////////

    function leftbar(x,y){
      var leftbarImg, leftbar
      leftbar = createImg("images/left bar coding.png");
      leftbar.position(x,y);
      leftbar.size(80,80);
    }
    leftbar(443,165);
    leftbar(443,250)
    leftbar(443,336)


    var arrowImg,arrow
    arrow = createImg("images/arrow coding.png");
    arrow.position(556,480)
    arrow.size(270,105)
    

    var dressUpImg,dressUp
    dressUp = createImg("images/dressUp.svg");
    dressUp.position(455,170)
    dressUp.size(40,40)
    
    var characterImg,character
    character = createImg("images/character.svg");
    character.position(455,255)
    character.size(40,40)

    var bgleftbarImg,bgleftbar
    bgleftbar = createImg("images/bgleftbar.svg");
    bgleftbar.position(455,340)
    bgleftbar.size(40,40)

     var backgroundImg,background
     backgroundImg = loadImage("images/background.png")
     background = createSprite(657,355,20,20);
     background.addImage(backgroundImg);
     background.scale = 0.5


     fill("yellow")
     rect(445,90,150,40);
 
     fill("red")
     text("score: ",450,115)
 

  
    //////////////button///////////////

     var button1 = createButton("Start");
     button1.position(655,520)

    // button1.mousePressed(()=>{
      //input.hide();
      //title.hide();
      //  console.log("hi")
     // });

    var button2 = createButton("Dress Up");
    button2.position(443,211)

    var button3 = createButton("Character");
    button3.position(443,295)

    var button4 = createButton("Background");
    button4.position(443,383)
 
    ///////////////////////////////////////////////////////

    

   
    }
}

